﻿using _6_2_interfejsy.classes;
using _6_2_interfejsy.interfaces;

namespace _6_2_interfejsy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IPlayable[] tabMedia = new IPlayable[4];

            tabMedia[0] = new Film();
            tabMedia[1] = new Film();
            tabMedia[2] = new Music();
            tabMedia[3] = new Comedy();

            foreach (IPlayable media in tabMedia)
            {
                media.Stop();
            }
            Console.WriteLine();

            /*
            for (int i = 0; i < tabMedia.Length; i++)
            {
                tabMedia[i].Stop();
            }
            Console.WriteLine();
            */

        }
    }
}