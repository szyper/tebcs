﻿using _6_2_interfejsy.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_2_interfejsy.classes
{
    internal class Music : IPlayable
    {
        public void Stop()
        {
            Console.WriteLine("Klasa Music - metoda STOP");
        }

        public void Pause()
        {
            Console.WriteLine("Klasa Music - metoda PAUSE");
        }

        public void Play()
        {
            Console.WriteLine("Klasa Music - metoda PLAY");
        }
    }
}
